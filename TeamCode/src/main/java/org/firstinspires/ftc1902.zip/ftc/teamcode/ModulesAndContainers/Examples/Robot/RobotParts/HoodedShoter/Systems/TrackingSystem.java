package org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Robot.RobotParts.HoodedShoter.Systems;

import com.qualcomm.robotcore.eventloop.opmode.OpMode;

import org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Robot.RobotParts.DriveTrain.Odometry.Parts.MathUtils.PIDF;
import org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Robot.RobotParts.DriveTrain.ProgramState;
import org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Robot.RobotParts.HoodedShoter.HoodedShoter;
import org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Robot.RobotParts.HoodedShoter.Modules.TurretMotor;
import org.firstinspires.ftc.teamcode.ModulesAndContainers.Modules.Extenders.ExecutableModule;

public class TrackingSystem extends ExecutableModule {
    private TurretMotor turretMotor;

    public TrackingSystem(OpMode op, HoodedShoter hoodedShoter) {
        super(op, "TurretClass");

        turretMotor = hoodedShoter.turretMotor;
    }
    private DriveEmulator driveEmulator;
    private final double outPutRes = 288;
    private final double RAD = 180/Math.PI;
    private boolean goToZero;

    public ProgramState execute(){
        double volT = 0;
        double target = 0;

        if (turretMotor.getWrapper().getMotor().getCurrentPosition() > outPutRes){
           goToZero = true;
        }

        if(goToZero){
            target = 0;
            volT = driveEmulator.calculateVol(target, turretMotor.turretOdometry.turrelLocalHead, 60);
        }else {
            target = turretMotor.turretOdometry.turretAbsoluteAngle + turretMotor.turretOdometry.cameraClass.cameraBearing;
            volT = driveEmulator.calculateVol(target, turretMotor.turretOdometry.turretAbsoluteAngle, 60);
        }

        turretMotor.setPower(volT);
        if(volT == 0){
            return ProgramState.Finished;
        }
        return ProgramState.Executing;
    }
    @Override
    public void showData() {
        telemetry.addLine("===TURRET===");

        telemetry.addLine();
    }
    public class DriveEmulator {
        private PIDF trackingPIDF;
        public DriveEmulator(){
            this.trackingPIDF = new PIDF(0.45, 0.0,0,0, -1, 1);
        }
        private double returnDistance(double VelMax, double accel ){
            return Math.pow(VelMax, 2) / (2 * accel);
        }
        public double calculateVol(double targetAngle, double curentAngle, double targetHeadVel){
            double errorHeading = targetAngle - curentAngle;

            double headVel = errorHeading > returnDistance(targetHeadVel, MAX_ANGULAR_ACCEL) ? targetHeadVel : MIN_ANGULAR_SPEED;

            double pidHeadVel = trackingPIDF.calculate(headVel);

            if(Math.abs(errorHeading) < Math.toRadians(1.5)) {
                pidHeadVel = 0;
            }

            return pidHeadVel;
        }
    }

}
