package org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Robot.RobotParts.HoodedShoter.Systems;

import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.hardware.DcMotor;

import org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Robot.RobotParts.DriveTrain.DrivetrainParts.Odometry.Parts.MathUtils.PIDF;
import org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Robot.RobotParts.DriveTrain.ProgramState;
import org.firstinspires.ftc.teamcode.ModulesAndContainers.Modules.Extenders.ExecutableModule;

public class TurretSystem extends ExecutableModule {
    private DcMotor turretMotor;

    public TurretSystem(OpMode op) {
        super(op, "TurretClass");

        try {
            this.turretMotor = hardwareMap.get(DcMotor.class, "m1");
        } catch (Exception e) {
            isInizialized = false;
            return;
        }

        this.turretMotor.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
    }
    private TrackingSystem trackingSystem;
    private TurretOdometry turretOdometry;
    private final double outPutRes = 288;
    private final double RAD = 180/Math.PI;
    private boolean goToZero;

    public ProgramState execute(){
        double volT = 0;
        double target = 0;

        if (turretMotor.getCurrentPosition() > outPutRes){
           goToZero = true;
        }

        if(goToZero){
            target = 0;
            volT = trackingSystem.calculateVol(target, turretOdometry.turrelLocalHead, 60);
        }else {
            target = turretOdometry.turretAbsoluteAngle + turretOdometry.cameraClass.cameraBearing;
            volT = trackingSystem.calculateVol(target, turretOdometry.turretAbsoluteAngle, 60);
        }

        turretMotor.setPower(volT);
        if(volT == 0){
            return ProgramState.Finished;
        }
        return ProgramState.Executing;
    }
    @Override
    public void showData() {
        telemetry.addLine("===TURRET===");
        if (isInizialized) {
            telemetry.addData("Turret state", turretState.toString());
            telemetry.addData("ticks", curMotorPos);
            telemetry.addData("Pow", turretMotor.getPower());
            telemetry.addData("State", tagState.toString());
            telemetry.addData("bear", cameraBearing * RAD);
            telemetry.addData("target", target * RAD);
        }else{
            telemetry.addLine("DEVICE NOT FOUND");
        }
        telemetry.addLine();
    }
    public class TrackingSystem {
        private PIDF trackingPIDF;
        public TrackingSystem(){
            this.trackingPIDF = new PIDF(0.45, 0.0,0,0, -1, 1);
        }
        private double returnDistance(double VelMax, double accel ){
            return Math.pow(VelMax, 2) / (2 * accel);
        }
        public double calculateVol(double targetAngle, double curentAngle, double targetHeadVel){
            double errorHeading = targetAngle - curentAngle;

            double headVel = errorHeading > returnDistance(targetHeadVel, MAX_ANGULAR_ACCEL) ? targetHeadVel : MIN_ANGULAR_SPEED;

            double pidHeadVel = trackingPIDF.calculate(headVel);

            if(Math.abs(errorHeading) < Math.toRadians(1.5)) {
                pidHeadVel = 0;
            }

            return pidHeadVel;
        }
    }

}
