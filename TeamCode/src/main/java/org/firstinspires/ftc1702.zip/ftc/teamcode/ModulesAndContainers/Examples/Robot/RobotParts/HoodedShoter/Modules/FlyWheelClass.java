package org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Robot.RobotParts.HoodedShoter.Modules;

import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.util.Range;

import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Robot.RobotParts.DriveTrain.DrivetrainParts.Odometry.Parts.MathUtils.PIDF;
import org.firstinspires.ftc.teamcode.ModulesAndContainers.Modules.Extenders.MotorModule;

public class FlyWheelClass extends MotorModule {
    public FlyWheelClass(OpMode op) {
        super(op);
        motorsWrapper
                .add(op, dcMotorEx.initialize("flyWheelRight").setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER).setBehavior(DcMotor.ZeroPowerBehavior.FLOAT).get())
                .add(op, dcMotorEx.initialize("flyWheelLeft").setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER).setBehavior(DcMotor.ZeroPowerBehavior.FLOAT).get());

        pidfFlyWheel = new PIDF();
    }
    public enum FlyWheelStates{
        Ready,
        Unready
    }
    public enum Units{
        Meters_in_sec,
        Rad_in_sec
    }
    public enum ControlMode{
        By_power,
        By_speed
    }
    public PIDF pidfFlyWheel;
    public double curVel, curLeftVel, curRightVel, inTakeCurPower;
    public double lastIntakePower;
    private double kPower;
    public double targSpeed;
    private double  P = FLYWHEEL[0], I = FLYWHEEL[1], D = FLYWHEEL[2], F = FLYWHEEL[3];
    private double pG ,iG ,dG , fG;
    private double errorPart;
    double filteredLeftVel = 0;
    double filteredRightVel = 0;
    double alpha = 0.3;
    public boolean flag;
    public int stopTimes;
    public double lastPower;
    public void setPower(double power){
        // 3. Компенсация напряжения
        double currentVoltage = voltageSensorClass.getCurVoltage();
        if (currentVoltage <= 0) currentVoltage = 11.5;

        double voltageMultiplier = 11.5 / currentVoltage;

        power *= voltageMultiplier;

        power = Range.clip(power, -1.0, 1.0);


        motorsWrapper.get("flyWheelRight").setPower(power);
        motorsWrapper.get("flyWheelLeft").setPower(-power);
    }
    public void setPIDF(double P, double I, double D, double F){
        switch (controlMode){
            case By_power:
                this.P = P;
                this.I = I;
                this.D = D;
                this.F = F;
                break;
            case By_speed:
                motorLeft.setVelocityPIDFCoefficients(P, I, D, F);
                motorRight.setVelocityPIDFCoefficients(P, I, D, F);
                break;
        }
    }
    public void resetPIDF(){
        P = FLYWHEEL[0];
        I = FLYWHEEL[1];
        D = FLYWHEEL[2];
        F = FLYWHEEL[3];
    }
    public void setPower(double targetIntakePow){
        targetIntakePow *= voltageSensorClass.getkPower();

        if (targetIntakePow == lastIntakePower) return;
//        if(Math.abs(inTakeCurPower - targetIntakePow) < 0.1) return;

        lastIntakePower = targetIntakePow;

        inTakeMotor.setPower(targetIntakePow);

        inTakeCurPower = inTakeMotor.getPower();

        runTimeIntake.reset();
    }

    public void setPreferences(CollectorMotors.ControlMode controlMode, CollectorMotors.Units units){
        this.units = units;
        this.controlMode = controlMode;

        switch (controlMode){
            case By_power:
                motorLeft.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);//Запускаем
                motorRight.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
                break;
            case By_speed:
                motorLeft.setMode(DcMotor.RunMode.RUN_USING_ENCODER);//Запускаем
                motorRight.setMode(DcMotor.RunMode.RUN_USING_ENCODER);

                motorLeft.setVelocityPIDFCoefficients(P, I, D, F);
                motorRight.setVelocityPIDFCoefficients(P, I, D, F);
                break;
        }
    }
    public void setSpeedFlyWheel(double speed){
        targSpeed = speed * 19.2;
        if (targSpeed == 0) innerTime.reset();

        switch (controlMode){
            case By_speed:
                motorLeft.setVelocity(speed, AngleUnit.RADIANS);
                motorRight.setVelocity(-speed, AngleUnit.RADIANS);

                pG = motorRight.getPIDFCoefficients(DcMotor.RunMode.RUN_USING_ENCODER).p;
                iG = motorRight.getPIDFCoefficients(DcMotor.RunMode.RUN_USING_ENCODER).i;
                dG = motorRight.getPIDFCoefficients(DcMotor.RunMode.RUN_USING_ENCODER).d;
                fG = motorRight.getPIDFCoefficients(DcMotor.RunMode.RUN_USING_ENCODER).f;

                calcCurSpeed();
                break;
            case By_power:
                setPowerFlyWheel(speed);
                break;
        }

        checkReadiness();
    }



    public void checkReadiness(){
        errorPart = Math.abs(curVel / targSpeed - 1);

        if (errorPart > 0.01)
        {
            flyWheelStates = CollectorMotors.FlyWheelStates.Unready;
            runTimeFlyWheel.reset();
        }
        else {
            flyWheelStates = CollectorMotors.FlyWheelStates.Ready;
        }
    }
    public void smoothBreak(){
        if (power == 0){
            if (flag) {
                lastPower = Math.abs(power);
                flag = false;
            }
            switch (stopTimes){
                case 0:
                    power = lastPower * 0.9;
                    stopTimes++;
                    break;
                case 1:
                    power = lastPower * 0.85;
                    stopTimes++;
                    break;
                case 2:
                    power = lastPower * 0.8;
                    stopTimes++;
                    break;
                case 3:
                    power = lastPower * 0.75;
                    stopTimes++;
                    break;
                case 4:
                    power = lastPower * 0.7;
                    stopTimes++;
                    break;
                case 5:
                    power = lastPower * 0.65;
                    stopTimes++;
                    break;
                case 6:
                    power = lastPower * 0.6;
                    stopTimes++;
                    break;
                case 7:
                    power = lastPower * 0.55;
                    stopTimes++;
                    break;
                case 8:
                    power = lastPower * 0.5;
                    stopTimes++;
                    break;
                case 9:
                    power = lastPower * 0.4;
                    stopTimes++;
                    break;
                case 10:
                    power = lastPower * 0.3;
                    stopTimes++;
                    break;
                case 11:
                    power = lastPower * 0.2;
                    stopTimes++;
                    break;
                case 12:
                    power = lastPower * 0.1;
                    stopTimes++;
                    break;
                case 13:
                    power = 0;
                    break;
            }
        }else
        {
            flag = true;
            stopTimes = 0;
        }
    }
    @Override
    public void showData() {

    }
    public class FlyWheelMath{
        public void calcCurSpeed(){
            curLeftVel = motorLeft.getVelocity(AngleUnit.RADIANS) * 19.2;
            curRightVel = motorRight.getVelocity(AngleUnit.RADIANS) * 19.2;

            filteredLeftVel  = alpha * filteredLeftVel  + (1 - alpha) * curLeftVel;
            filteredRightVel = alpha * filteredRightVel + (1 - alpha) * curRightVel;


            curVel = filteredLeftVel != 0 && filteredRightVel != 0 ? (filteredLeftVel + filteredRightVel) / 2.0 : filteredLeftVel + filteredRightVel;

            if (units == CollectorMotors.Units.Meters_in_sec)
            {
                targSpeed = targSpeed / MAX_RAD_SPEED * MAX_EXPERIMENTAL_SPEED_IN_METERS;
                curVel = curVel / MAX_RAD_SPEED * MAX_EXPERIMENTAL_SPEED_IN_METERS;
            }
        }

    }
}
