package org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Robot.RobotParts.DriveTrain.DrivetrainParts;

import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;

import org.firstinspires.ftc.teamcode.ModulesAndContainers.Modules.Extenders.MotorModule;

public class DrivetrainMotors extends MotorModule {
    public DrivetrainMotors(OpMode op) {
        super(op);

        motorsWrapper
                .add(op, dcMotor.initialize("rightB").setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER).setDirection(DcMotorSimple.Direction.FORWARD).setBehavior(DcMotor.ZeroPowerBehavior.FLOAT).get())
                .add(op, dcMotor.initialize("rightF").setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER).setDirection(DcMotorSimple.Direction.FORWARD).setBehavior(DcMotor.ZeroPowerBehavior.FLOAT).get())
                .add(op, dcMotor.initialize("leftF").setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER).setDirection(DcMotorSimple.Direction.REVERSE).setBehavior(DcMotor.ZeroPowerBehavior.FLOAT).get())
                .add(op, dcMotor.initialize("leftB").setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER).setDirection(DcMotorSimple.Direction.REVERSE).setBehavior(DcMotor.ZeroPowerBehavior.FLOAT).get());

        telemetry.addLine("Motors on drivetrain Inited");
    }
    public void setPower(double forwardPow, double sidePow, double anglePow){

        double minPow = 0.13 / voltageSensorClass.getkPower();

        if(voltageSensorClass.getkPower() != 0){
            forwardPow = forwardPow * 12.5 / voltageSensorClass.getCurVoltage();
            sidePow = sidePow * 12.5 / voltageSensorClass.getCurVoltage();
            anglePow = anglePow * 12.5 / voltageSensorClass.getCurVoltage();
        }

//        if(forwardPow != 0 && Math.abs(forwardPow) < minPow) forwardPow = Math.signum(forwardPow) * minPow;
//        if(sidePow != 0 &&  Math.abs(sidePow) < minPow) sidePow = Math.signum(sidePow) * minPow;
//        if(anglePow != 0 &&  Math.abs(anglePow) < minPow) anglePow = Math.signum(anglePow) * minPow;

        double powRightB = forwardPow - sidePow + anglePow;
        double powRightF = forwardPow + sidePow + anglePow;
        double powlLeftF = forwardPow - sidePow - anglePow;
        double powLeftB = forwardPow + sidePow - anglePow;

        motorsWrapper.get("rightB").setPower(powRightB);
        motorsWrapper.get("rightF").setPower(powRightF);
        motorsWrapper.get("leftF").setPower(powlLeftF);
        motorsWrapper.get("leftB").setPower(powLeftB);
    }


    @Override
    public void showData() {
        telemetry.addLine("===DRIVETRAIN MOTORS===");
        if (isInizialized) {
            telemetry.addData("Powers right side", "RF:%.2f RB:%.2f",  motorsWrapper.get("rightF").getPower(), motorsWrapper.get("rightB").getPower());
            telemetry.addData("Powers left side", "LF:%.2f LB:%.2f", motorsWrapper.get("leftF").getPower(),  motorsWrapper.get("leftB").getPower());
        }else{
            telemetry.addLine("DEVICE NOT FOUND");
        }
        telemetry.addLine();
    }
}
