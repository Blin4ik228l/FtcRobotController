package org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Players.Pl2;

import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.util.ElapsedTime;
import com.qualcomm.robotcore.util.Range;

import org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Joysticks.Extenders.Joystick2;
import org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Players.PlayerClass;
import org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.GeneralInformation;
import org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Robot.RobotParts.HoodedShoter.HoodedShoter;
import org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Robot.RobotParts.HoodedShoter.Systems.CollectorSystem;
import org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Robot.RobotParts.HoodedShoter.Systems.FireSystem;
import org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Robot.RobotParts.HoodedShoter.Systems.TurretSystem;
import org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Robot.Wrappers.ColorSensorWrapper;
import org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Robot.RobotParts.CameraClass;
import org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Robot.RobotParts.DriveTrain.DrivetrainParts.Odometry.Odometry;
import org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Robot.RobotParts.DriveTrain.DrivetrainParts.PositionController;
import org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Robot.RobotParts.DriveTrain.ProgramState;
import org.firstinspires.ftc.teamcode.ModulesAndContainers.Modules.Module;

public class AutoPlayerClass2 extends PlayerClass{
    public AutoPlayerClass2(GeneralInformation generalInformation, HoodedShoter hoodedShoter, OpMode op) {
        super(generalInformation, op);
        this.hoodedShoter = hoodedShoter;

        this.matchTime = matchTime;

        vyrState = PositionController.VyrState.Far_from_it;
        moveState = Odometry.MoveState.High_speed;
        rotateState = Odometry.RotateState.High_speed;
        randomizeStatus = CameraClass.RandomizeStatus.UnDetected;

        generalState = GeneralState.LoadLogic;
        loadState = LoadState.Prepare;
        fireState = FireState.Prepare;
        anotherStates = AnotherStates.Prepare;

        setJoystickActivityClass(new Joystick2(op));
    }
    public StateMachine.Builder player2Program = new StateMachine.Builder()
            .addProgram(new LoadMachine())
            .addProgram(new FireMachine());

    public HoodedShoter hoodedShoter;
    public CollectorSystem collectorSystem;
    public FireSystem fireSystem;
    public TurretSystem turretSystem;
    @Override
    public void execute(){

        if (range >= 290) theta = 50;
        else if (range >= 150) theta = 60;
        else if (range >= 70) theta = 70;
        else theta = 80;

        calcAngle();
        calcAngleToPos();
        calcSpeed();

        targetRadSpeed = (targetSpeed / MAX_EXPERIMENTAL_SPEED_IN_METERS * MAX_RAD_SPEED);

        checkButtons();
    }
    @Override
    public void buttonAReleased() {

    }

    @Override
    public void buttonAUnReleased() {

    }

    @Override
    public void buttonBReleased() {

    }

    @Override
    public void buttonBUnReleased() {

    }

    @Override
    public void buttonXReleased() {
        joystickActivityClass.tDpadUpPressed = 0;
        joystickActivityClass.buttonBack = false;
        joystickActivityClass.bumperLeft = false;
        joystickActivityClass.tLeftBumperPressed = 0;
        joystickActivityClass.tRightBumperPressed = 0;

    }

    @Override
    public void buttonXUnReleased() {
      
    }

    @Override
    public void buttonYReleased() {

    }

    @Override
    public void buttonYUnReleased() {

    }

    public void rotateBaraban(int targCell){
        double targPos;

        switch (targCell){
            case 0:
                targPos = BARABAN_CELL0_POS;
                break;
            case 1:
                targPos = BARABAN_CELL1_POS;
                break;
            default:
                targPos = BARABAN_CELL2_POS;
                break;
        }

        hoodedShoter.servos.setBaraban(targPos);
    }
    private void calcAngleToPos(){
        double rampAngle = Range.clip(90 - Math.toDegrees(targetAngle), MIN_ANGLE, MAX_ANGLE);

        targetServoPos =  (MAX_ANGLE - rampAngle) * (185 / 23) / 270;

        targetServoPos = Math.round(targetServoPos * Math.pow(10, 2)) / Math.pow(10, 2);
    }
    private void calcAngle(){
        double alpha = Math.toRadians(theta);
//        int h = 79;
//
//        targetAngle =  Math.atan(Math.tan(alpha) + 2 * (h) / range);

        targetAngle = alpha;

        targetAngle = Math.round(targetAngle * Math.pow(10, 1)) / Math.pow(10, 1);
    }
    private void calcSpeed(){
        double alpha = Math.toRadians(theta);

//        targetSpeed =  Math.sqrt(Math.abs(981 * range / ((Math.tan(alpha) + Math.tan(targetAngle)) * Math.pow(Math.cos(targetAngle), 2)))) / 100;

//        targetSpeed = Math.sqrt((981 * Math.pow(range, 2)) / (2 * Math.pow(Math.cos(alpha), 2) * (range * Math.tan(alpha) - (79))))/ 100;

        targetSpeed = (range / Math.cos(alpha)) * Math.sqrt(Math.abs(981 / (2 * (range * Math.tan(alpha) - 80)))) / 100;

        if (981 / (2 * (range * Math.tan(alpha) - 80)) < 0) targetSpeed = 0;

        targetSpeed = Math.round(targetSpeed * Math.pow(10, 1)) / Math.pow(10, 1);
    }
    private boolean isLoadEnded(){
        return hoodedShoter.digitalCellsClass.isMaxed;
    }
    @Override
    public void showData(){
        telemetry.addLine("===AUTO PLAYER===");
        telemetry.addData("Automatic state", generalState.toString());

        if(generalState == GeneralState.LoadLogic){
            telemetry.addData("Load state", loadState.toString());
        }else
        {
            telemetry.addData("Fire state", fireState.toString());
            telemetry.addData("Another state", anotherStates.toString());
        }


        if(fireState == FireState.Fire && anotherStates == AnotherStates.Push)
        {
            telemetry.addData("FlyWheel", hoodedShoter.motors.flyWheelStates.toString());
            telemetry.addData("Randomize", randomizeStatus.toString());
            telemetry.addData("VyrState", vyrState.toString());
            telemetry.addData("MoveState", moveState.toString());
            telemetry.addData("RotateState", rotateState.toString());
        }
        telemetry.addLine();
    }

    public class LoadMachine extends Module {

        public Builder mainProgram;
        public LoadMachine(String name) {
            super(name);

            hoodedShoter.motors.setSpeedFlyWheel(0);

            this.mainProgram = new Builder()
                    .addProgram(new StateMachine("Prepare") {
                        @Override
                        public ProgramState execute() {
                            hoodedShoter.servos.setAngle(ANGLE_UPPER_POS);

                            hoodedShoter.motors.offIntake();
                            hoodedShoter.servos.setPusherHor(PUSHER_START_POS);

                            if(isPushHorEnded()){
                                return ProgramState.Finished;
                            }else return ProgramState.Executing;
                        }
                    })
                    .addProgram(new StateMachine("WaitingForArtifact") {
                        @Override
                        public ProgramState execute() {
                            if (hoodedShoter.colorSensorWrapper.colorState == ColorSensorWrapper.ColorSensorState.Artifact_Detected){
                                hoodedShoter.motors.offIntake();
                                hoodedShoter.digitalCellsClass.setColor(hoodedShoter.colorSensorWrapper.getFoundedColor());
                                return ProgramState.Finished;
                            }else {
                                hoodedShoter.motors.onIntake();
                                return ProgramState.Executing;
                            }

                        }
                    })
                    .addProgram(new StateMachine("CheckNumbersArtifacts") {
                        @Override
                        public ProgramState execute() {
                            if(isLoadEnded())
                            {
                                return ProgramState.Finished;
                            }
                            else
                            {
                                return ProgramState.Executing;
                            }
                        }
                    })
                    .addProgram(new StateMachine("PrepareToNextState") {
                        @Override
                        public ProgramState execute() {
                            hoodedShoter.motors.reverseInTake();
                            if (hoodedShoter.motors.getRunTimeIntake().seconds() > REVERSE_DELAY) {
                                hoodedShoter.motors.offIntake();
                                return ProgramState.Finished;
                            }else return ProgramState.Executing;
                        }
                    })
            ;
        }
        @Override
        public ProgramState execute() {
            ProgramState result = mainProgram.execute();

            ProgramState mainResult = ProgramState.Executing;
            switch (result){
                case Finished:
                    mainProgram.switchActiveProgram();
                    if (mainProgram.isLastProgramWasExecuted()){
                        mainProgram.switchActiveProgramToStart();
                        mainResult = ProgramState.Finished;
                    }
                    break;
                case Executing:
                    if (mainProgram.getName() == "CheckNumbersArtifacts"){
                        mainProgram.switchActiveProgramTo("FindNeededCell");
                    }
                    break;
            }
            return mainResult;
        }
    }
    public class FireMachine extends Module {
        public Builder mainProgram;

        public FireMachine(String name) {
            super(name);
            this.mainProgram = new Builder()
                    .addProgram(new StateMachine("Prepare") {
                        @Override
                        public ProgramState execute() {
                            hoodedShoter.servos.setPusherHor(PUSHER_PREFIRE_POS);

                            if (isPushHorEnded()){
                                fireState = FireState.Find;
                                return ProgramState.Finished;
                            }else return ProgramState.Executing;
                        }
                    })
                    .addProgram(new StateMachine("FindNeededCell") {
                        @Override
                        public ProgramState execute() {
                            int targCell = 0;
                            switch (generalInformation.programName){
                                case TeleOp:
                                    if(matchTimer.seconds() > 120)
                                    {
                                        targCell = hoodedShoter.digitalCellsClass.getFullCell();
                                    }else {
                                        int targetCellIndex = 3 - hoodedShoter.digitalCellsClass.getArtifactCount(); // 3→0, 2→1, 1→2
                                        int targetColor = hoodedShoter.digitalCellsClass.getRandomizedArtifact()[targetCellIndex];

                                        targCell = hoodedShoter.digitalCellsClass.findNeededCell(targetColor);
                                    }
                                    break;
                                case Auto:
                                    int targetCellIndex = 3 - hoodedShoter.digitalCellsClass.getArtifactCount(); // 3→0, 2→1, 1→2
                                    int targetColor = hoodedShoter.digitalCellsClass.getRandomizedArtifact()[targetCellIndex];

                                    targCell = hoodedShoter.digitalCellsClass.findNeededCell(targetColor);
                                    break;
                            }

                            rotateBaraban(targCell);

                            if (isRotateEndedToFire()){
                                fireState = FireState.Fire;
                                return ProgramState.Finished;
                            }else return ProgramState.Executing;
                        }
                    })
                    .addProgram(new StateMachine("WaitingForArtifact") {
                        @Override
                        public ProgramState execute() {
                            switch (anotherStates){
                                case Prepare:
                                    hoodedShoter.servos.setPusherVer(PUSHERVER_ENDING_POS);
                                    if(isPushVerEnded()){
                                        anotherStates = AnotherStates.Waiting;
                                    }
                                    break;

                                case Waiting:
                                    if (!(moveState == Odometry.MoveState.High_speed || rotateState == Odometry.RotateState.High_speed
                                            || hoodedShoter.motors.flyWheelStates == CollectorMotors.FlyWheelStates.Unready || !once))
                                    {
                                        hoodedShoter.motors.setPIDF(hoodedShoter.motors.getPIDF()[0], hoodedShoter.motors.getPIDF()[1], hoodedShoter.motors.getPIDF()[2], hoodedShoter.motors.getPIDF()[3] * 1.05) ;
                                        anotherStates = AnotherStates.Push;
                                    }
                                    break;

                                case Push:
                                    hoodedShoter.servos.setPusherHor(PUSHERHOR_ENDING_POS);
                                    if (isPushHorEnded()){
                                        hoodedShoter.motors.resetPIDF();
                                        anotherStates = AnotherStates.Back;
                                    }
                                    break;

                                case Back:
                                    hoodedShoter.servos.setPusherVer(PUSHERVER_START_POS);
                                    hoodedShoter.servos.setPusherHor(PUSHER_PREFIRE_POS);

                                    if (isPushHorEnded()){
                                        if (hoodedShoter.colorSensorWrapper.colorState == ColorSensorWrapper.ColorSensorState.No_Artifact_Detected)
                                        {
                                            hoodedShoter.digitalCellsClass.deleteColorFromCell();
                                            fireState = FireState.Idle;
                                        }

                                        anotherStates = AnotherStates.Prepare;
                                    }
                                    break;
                            }
                            return ProgramState.Executing;
                        }
                    })
                    .addProgram(new StateMachine("CheckNumbersArtifacts") {
                        @Override
                        public ProgramState execute() {
                            if (hoodedShoter.digitalCellsClass.getArtifactCount() == 0)
                            {
                                hoodedShoter.servos.setAngle(ANGLE_UPPER_POS);
                                joystickActivityClass.buttonY = false;

                                generalState = GeneralState.LoadLogic;
                                loadState = LoadState.Prepare;
                                return ProgramState.Finished;
                            }
                            else return ProgramState.Executing;
                        }
                    })
                    .addProgram(new StateMachine("PrepareToNextState") {
                        @Override
                        public ProgramState execute() {
                            hoodedShoter.motors.reverseInTake();
                            if (hoodedShoter.motors.getRunTimeIntake().seconds() > REVERSE_DELAY) {
                                hoodedShoter.motors.offIntake();
                                return ProgramState.Finished;
                            }else return ProgramState.Executing;
                        }
                    });
        }

        @Override
        public ProgramState execute() {
            hoodedShoter.motors.setSpeedFlyWheel(targetRadSpeed);
            hoodedShoter.servos.setAngle(targetServoPos);


            return null;
        }
    }

}
