package org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Robot.RobotParts.HoodedShoter.Modules;

import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.util.Range;

import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Robot.RobotParts.DriveTrain.Odometry.Parts.MathUtils.PIDF;
import org.firstinspires.ftc.teamcode.ModulesAndContainers.Modules.Extenders.MotorModule;

public class FlyWheelClass extends MotorModule {
    public FlyWheelClass(OpMode op) {
        super(op);
        motorsWrapper
                .add(op, dcMotorEx.initialize("flyWheelRight").setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER).setBehavior(DcMotor.ZeroPowerBehavior.FLOAT).get())
                .add(op, dcMotorEx.initialize("flyWheelLeft").setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER).setBehavior(DcMotor.ZeroPowerBehavior.FLOAT).get());


    }

    public double lastIntakePower;
    private double kPower;
    public double targSpeed;
    private double  P = FLYWHEEL[0], I = FLYWHEEL[1], D = FLYWHEEL[2], F = FLYWHEEL[3];
    private double pG ,iG ,dG , fG;
    private double errorPart;
    double filteredLeftVel = 0;
    double filteredRightVel = 0;
    double alpha = 0.3;
    public boolean flag;
    public int stopTimes;
    public double lastPower;
    public double radius = 0.4;
    public boolean switcher = false;

    public double getCurVelocity(){
        double left = motorsWrapper.get("motorLeft").getMotor().getVelocity(AngleUnit.RADIANS) * 19.2;
        double right = motorsWrapper.get("motorRight").getMotor().getVelocity(AngleUnit.RADIANS) * 19.2;

        double vel = left != 0 && right != 0 ? (left + right) / 2.0 : left + right;
        return switcher ? vel : vel * radius;
    }
    public void setPower(double power){
        // 3. Компенсация напряжения
        double currentVoltage = voltageSensorClass.getCurVoltage();
        if (currentVoltage <= 0) currentVoltage = 11.5;

        double voltageMultiplier = 11.5 / currentVoltage;

        power *= voltageMultiplier;

        power = Range.clip(power, -1.0, 1.0);

        motorsWrapper.get("flyWheelRight").setPower(power);
        motorsWrapper.get("flyWheelLeft").setPower(-power);
    }
    public void resetPIDF(){
        P = FLYWHEEL[0];
        I = FLYWHEEL[1];
        D = FLYWHEEL[2];
        F = FLYWHEEL[3];
    }

    public void smoothBreak(){
        if (power == 0){
            if (flag) {
                lastPower = Math.abs(power);
                flag = false;
            }
            switch (stopTimes){
                case 0:
                    power = lastPower * 0.9;
                    stopTimes++;
                    break;
                case 1:
                    power = lastPower * 0.85;
                    stopTimes++;
                    break;
                case 2:
                    power = lastPower * 0.8;
                    stopTimes++;
                    break;
                case 3:
                    power = lastPower * 0.75;
                    stopTimes++;
                    break;
                case 4:
                    power = lastPower * 0.7;
                    stopTimes++;
                    break;
                case 5:
                    power = lastPower * 0.65;
                    stopTimes++;
                    break;
                case 6:
                    power = lastPower * 0.6;
                    stopTimes++;
                    break;
                case 7:
                    power = lastPower * 0.55;
                    stopTimes++;
                    break;
                case 8:
                    power = lastPower * 0.5;
                    stopTimes++;
                    break;
                case 9:
                    power = lastPower * 0.4;
                    stopTimes++;
                    break;
                case 10:
                    power = lastPower * 0.3;
                    stopTimes++;
                    break;
                case 11:
                    power = lastPower * 0.2;
                    stopTimes++;
                    break;
                case 12:
                    power = lastPower * 0.1;
                    stopTimes++;
                    break;
                case 13:
                    power = 0;
                    break;
            }
        }else
        {
            flag = true;
            stopTimes = 0;
        }
    }
    @Override
    public void showData() {

    }
    public class FlyWheelMath{
        public void calcCurSpeed(){

        }

    }
}
