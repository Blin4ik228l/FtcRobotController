package org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Robot;

import com.qualcomm.robotcore.eventloop.opmode.OpMode;

import org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Robot.RobotParts.CameraClass;
import org.firstinspires.ftc.teamcode.ModulesAndContainers.Modules.Extenders.UpdatableModule;
import org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Robot.RobotParts.HoodedShoter.HoodedShoter;
import org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Robot.RobotParts.DriveTrain.MecanumDrivetrain;
import org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Robot.RobotParts.VoltageSensorClass;

public class RobotClass extends UpdatableModule{
   /* Основная идея данного класса:
    Робот - это как конструктор, он состоит из разных частей
    Моя задача как программиста расписать каждый модуль(часть робота)
    Чтобы в дальнейшем ими легко управлять
    */
    public CameraClass cameraClass;
    public VoltageSensorClass voltageSensor;
    public MecanumDrivetrain drivetrain;
    public HoodedShoter hoodedShoter;

    public RobotClass(OpMode op){
        super(op);
        cameraClass = new CameraClass(op);
        voltageSensor = new VoltageSensorClass(op);

        drivetrain = new MecanumDrivetrain(op, cameraClass, voltageSensor);
        hoodedShoter = new HoodedShoter(op, cameraClass, voltageSensor);

//        hoodedShoter.motors.setPreferences(CollectorMotors.ControlMode.By_power, CollectorMotors.Units.Rad_in_sec);
    }

    @Override
    public void update() {
        if (iterationCount % 10 == 0) voltageSensor.update();

        drivetrain.update();

        hoodedShoter.update();
    }

    @Override
    public void showData(){
        telemetry.addData("Match time:", matchTimer.seconds());
        voltageSensor.showData();
        drivetrain.showData();
        hoodedShoter.showData();
    }
}


