package org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Robot.RobotParts.DriveTrain;

import com.qualcomm.robotcore.eventloop.opmode.OpMode;

import org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Robot.RobotParts.CameraClass;
import org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Robot.RobotParts.DriveTrain.DrivetrainParts.Odometry.Odometry;
import org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Robot.RobotParts.DriveTrain.DrivetrainParts.Odometry.OdometryData;
import org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Robot.RobotParts.VoltageSensorClass;
import org.firstinspires.ftc.teamcode.ModulesAndContainers.Modules.Extenders.UpdatableModule;
import org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Robot.RobotParts.DriveTrain.DrivetrainParts.DrivetrainMotors;

public class MecanumDrivetrain extends UpdatableModule {
    //Телега робота(моторы + колёса) с энкодерами, гироскопом и камерой.
    private DrivetrainMotors motors;
    private Odometry odometry;
    public MecanumDrivetrain(OpMode op, CameraClass cameraClass, VoltageSensorClass voltageSensorClass){
        super(op);
        try {
            motors = new DrivetrainMotors(op);
        }catch (Exception e){
            motors.isInizialized = false;
        }

        motors.setVoltageSensorClass(voltageSensorClass);
        odometry = new Odometry(op, cameraClass);

        telemetry.addLine("Drivetrain Inited");
    }

    public OdometryData getOdometryData(){
        return odometry.odometryBuffer.read();
    }
    public void setVoltageSensor(VoltageSensorClass voltageSensor){
        motors.setVoltageSensorClass(voltageSensor);
    }
    public void setPower(double forwardPow, double sidePow, double anglePow){
        motors.setPower(forwardPow, sidePow, anglePow);
    }

    @Override
    public void update() {

    }

    @Override
    public void showData() {
        telemetry.addLine("===DRIVETRAIN DATA===");
        odometry.showData();
        motors.showData();
    }
}
