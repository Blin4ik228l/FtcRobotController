package org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Robot.RobotParts.DriveTrain;

public enum Reason {
    ToFire,
    ToCollect,
    ToParking
}
