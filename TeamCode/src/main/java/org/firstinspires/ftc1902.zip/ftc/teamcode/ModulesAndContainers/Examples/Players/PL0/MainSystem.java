package org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Players.PL0;

import com.qualcomm.robotcore.eventloop.opmode.OpMode;

import org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.GeneralInformation;
import org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Players.Pl1.SemiAutoPlayerClass1;
import org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Players.Pl2.AutoPlayerClass2;
import org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Robot.RobotClass;
import org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Robot.RobotParts.DriveTrain.Reason;
import org.firstinspires.ftc.teamcode.ModulesAndContainers.Modules.Extenders.UpdatableModule;

public abstract class MainSystem extends UpdatableModule {
    public GeneralInformation generalInformation;
    public SemiAutoPlayerClass1 semiAutoPlayerClass1;
    public AutoPlayerClass2 autoPlayerClass2;
    public RobotClass robotClass;

    public Thread pl1, pl2, rob;
    public MainSystem(GeneralInformation generalInformation, RobotClass robotClass, OpMode op){
        super(op);

        this.generalInformation = generalInformation;
        this.semiAutoPlayerClass1 = new SemiAutoPlayerClass1(generalInformation, robotClass, op);
        this.autoPlayerClass2 = new AutoPlayerClass2(generalInformation, robotClass, op);
        this.robotClass = robotClass;
    }

    public void startExecuting(){
        int targetFrequencyHz = 50;  // 50 раз в секунду
        long targetPeriodNs = 1_000_000_000 / targetFrequencyHz;  // 20,000,000 нс
        long targetSleepMs = targetPeriodNs / 1_000_000;  // 20 мс


        Runnable player1 = new Runnable() {
            @Override
            public void run() {
                while (!Thread.currentThread().isInterrupted())
                {
                    long start = System.nanoTime();
                    semiAutoPlayerClass1.execute();

                    long elapsed = System.nanoTime() - start;
                    long sleepTime = targetPeriodNs - elapsed;

                    if (sleepTime > 0) {
                        try {
                            Thread.sleep(targetSleepMs);
                        } catch (InterruptedException e) {
                            Thread.currentThread().interrupt();
                        }
                    }
                }
            }
        };
        Runnable player2 = new Runnable() {
            @Override
            public void run() {
                while (!Thread.currentThread().isInterrupted())
                {
                    long start = System.nanoTime();
                    autoPlayerClass2.execute();

                    long elapsed = System.nanoTime() - start;
                    long sleepTime = targetPeriodNs - elapsed;

                    if (sleepTime > 0) {
                        try {
                            Thread.sleep(targetSleepMs);
                        } catch (InterruptedException e) {
                            Thread.currentThread().interrupt();
                        }
                    }
                }
            }
        };
        Runnable robot = new Runnable() {
            @Override
            public void run() {
                while (!Thread.currentThread().isInterrupted())
                {
                    long start = System.nanoTime();
                    robotClass.update();

                    long elapsed = System.nanoTime() - start;
                    long sleepTime = targetPeriodNs - elapsed;

                    if (sleepTime > 0) {
                        try {
                            Thread.sleep(targetSleepMs);
                        } catch (InterruptedException e) {
                            Thread.currentThread().interrupt();
                        }
                    }
                }

            }
        };

        pl1 = new Thread(player1);
        pl2 = new Thread(player2);
        rob = new Thread(robot);

        pl1.start();
        pl2.start();
        rob.start();
    }
    public void update() {
        switch (generalInformation.programName){
            case TeleOp:
                break;
            default:
                boolean isOnFirePos = false;
                boolean isOnCollectPos = false;
                boolean isAllCollected = false;
                boolean isAllFired = false;

                switch (semiAutoPlayerClass1.positionController.getReason()){
                    case GoToFirePos:
                        switch (semiAutoPlayerClass1.programState){
                            case Finished:
                                isOnFirePos = true;
                                break;
                            case Executing:
                                break;
                        }
                        break;
                    case GoToCollect:
                        switch (semiAutoPlayerClass1.programState){
                            case Finished:
                                isOnCollectPos = true;
                                break;
                            case Executing:
                                break;
                        }
                        break;
                }

                switch (autoPlayerClass2.program.getName()){
                    case "CollectorSystem":
                        switch (autoPlayerClass2.programState){
                            case Finished:
                                //собрали все 3
                                isAllCollected = true;
                                break;
                            case Executing:

                                break;

                        }
                        break;
                    case "FireSystem":
                        switch (autoPlayerClass2.programState){
                            case Finished:
                                //Отстреляли
                                isAllFired = true;
                                autoPlayerClass2.program.switchActiveProgram();
                                break;
                            case Executing:
                                break;

                        }
                        break;
                }

                if (isOnFirePos && isAllCollected){
                    autoPlayerClass2.program.switchActiveProgram();
                    return;
                }
                if(isAllFired && isOnFirePos){
                    autoPlayerClass2.program.switchActiveProgram();
                    semiAutoPlayerClass1.positionController.switchPos();
                    return;
                }
                if(!isAllCollected && isOnCollectPos){
                    semiAutoPlayerClass1.positionController.switchPos();
                    return;
                }
                if (isAllCollected){
                    if (semiAutoPlayerClass1.positionController.getReason() != Reason.GoToFirePos) semiAutoPlayerClass1.positionController.switchPos();
                }
                break;
        }


    }

    @Override
    public void showData() {
        telemetry.addLine("===MAIN SYSTEM===");


        telemetry.addLine();
    }


}
