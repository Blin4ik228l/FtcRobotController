package org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Robot.RobotParts.HoodedShoter.Systems;

import com.qualcomm.robotcore.eventloop.opmode.OpMode;

import org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Robot.RobotParts.HoodedShoter.Modules.DigitalCellsClass;
import org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Robot.RobotParts.HoodedShoter.Modules.FlyWheelClass;
import org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Robot.RobotParts.DriveTrain.ProgramState;
import org.firstinspires.ftc.teamcode.ModulesAndContainers.Modules.Extenders.ExecutableModule;

public class FireSystem extends ExecutableModule {
    public TurretSystem turretSystem;
    public FlyWheelClass flyWheelClass;
    public DigitalCellsClass digitalCellsClass;

    public FireSystem(OpMode op) {
        super(op, "FireSystem");
    }

    @Override
    public ProgramState execute() {

        return null;
    }

    @Override
    public void showData() {

    }
}
