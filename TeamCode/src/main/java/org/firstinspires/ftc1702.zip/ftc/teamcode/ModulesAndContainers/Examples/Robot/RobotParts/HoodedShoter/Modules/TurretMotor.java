package org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Robot.RobotParts.HoodedShoter.Modules;

import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.util.ElapsedTime;

import org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Robot.Wrappers.MotorWrapper;
import org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Robot.RobotParts.CameraClass;
import org.firstinspires.ftc.teamcode.ModulesAndContainers.Modules.Extenders.MotorModule;
import org.firstinspires.ftc.teamcode.ModulesAndContainers.Modules.Extenders.UpdatableModule;

public class TurretMotor extends MotorModule {
    public TurretOdometry turretOdometry;
    public TurretMotor(OpMode op, CameraClass cameraClass) {
        super(op);
        motorsWrapper.add(op, dcMotorEx.initialize("turretMotor").setBehavior(DcMotor.ZeroPowerBehavior.FLOAT).setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER).get());

        turretOdometry = new TurretOdometry(op, cameraClass);
    }
    public void setPower(double headPow){
        motorsWrapper.get("turretMotor").setPower(headPow);
    }
    public MotorWrapper getMotor(){
        return motorsWrapper.get("turretMotor");
    }
    @Override
    public void showData() {

    }
    public class TurretOdometry extends UpdatableModule {
        private CameraClass cameraClass;
        public TurretOdometry(OpMode op, CameraClass cameraClass) {
            super(op);
            this.cameraClass = cameraClass;
            selfMath = new SelfMath();
        }
        private SelfMath selfMath;

        @Override
        public void update() {
            selfMath.calculateAll();
        }

        @Override
        public void showData() {

        }

        public class SelfMath{
            private double lastMotorPos, curMotorPos, deltaPos;
            private double deltaHead;
            private ElapsedTime runTime;
            private double curTime, deltaTime, lastTime;
            public double turretAbsoluteAngle, turrelLocalHead, headVel;
            public void calculateAll(){
                double outPutResolution = 288;

                curMotorPos = motorsWrapper.get("turretMotor").getMotor().getCurrentPosition();
                deltaPos = lastMotorPos - curMotorPos;
                lastMotorPos = curMotorPos;

                deltaHead = (deltaPos / outPutResolution * 2 * Math.PI);

                if (cameraClass.id == 20 || cameraClass.id == 24) {
                    turretAbsoluteAngle = cameraClass.absoluteData.getRobotPosition().getHeading();
                } else {
                    turretAbsoluteAngle += deltaHead;
                }

                curTime = runTime.milliseconds();
                deltaTime = curTime - lastTime;
                lastTime = curTime;

                headVel = deltaHead / (deltaTime / 1000);

                turrelLocalHead += deltaHead;
            }
        }
    }

}
