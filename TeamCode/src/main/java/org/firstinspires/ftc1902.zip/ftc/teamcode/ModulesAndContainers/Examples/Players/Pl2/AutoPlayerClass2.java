package org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Players.Pl2;

import com.qualcomm.robotcore.eventloop.opmode.OpMode;

import org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Joysticks.Extenders.Joystick2;
import org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Players.PlayerClass;
import org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.GeneralInformation;
import org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Robot.RobotClass;
import org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Robot.RobotParts.DriveTrain.Odometry.Odometry;
import org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Robot.RobotParts.DriveTrain.Odometry.Parts.MathUtils.PIDF;
import org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Robot.RobotParts.DriveTrain.Odometry.Parts.MathUtils.Vector2;
import org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Robot.RobotParts.HoodedShoter.HoodedShoter;
import org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Robot.RobotParts.HoodedShoter.Modules.AngleController;
import org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Robot.RobotParts.HoodedShoter.Modules.Collector;
import org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Robot.RobotParts.HoodedShoter.Modules.DigitalCellsClass;
import org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Robot.RobotParts.HoodedShoter.Modules.FlyWheelClass;

import org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Robot.RobotParts.DriveTrain.ProgramState;
import org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Robot.RobotParts.HoodedShoter.Systems.TrackingSystem;
import org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Robot.Wrappers.ServoMotorWrapper;
import org.firstinspires.ftc.teamcode.ModulesAndContainers.Modules.Extenders.ExecutableModule;

public class AutoPlayerClass2 extends PlayerClass{
    public AutoPlayerClass2(GeneralInformation generalInformation, RobotClass robotClass, OpMode op) {
        super(generalInformation, "Player2",op);
        this.hoodedShoter = robotClass.hoodedShoter;
        this.odometry = robotClass.odometry;

        collectorSystem = new CollectorSystem(op, hoodedShoter);
        fireSystem = new FireSystem(op, hoodedShoter);
        trackingSystem = new TrackingSystem(op, hoodedShoter);

        setJoystickActivityClass(new Joystick2(op));
    }

    public HoodedShoter hoodedShoter;
    public Odometry odometry;
    public CollectorSystem collectorSystem;
    public FireSystem fireSystem;
    public TrackingSystem trackingSystem;
    public Builder program = new Builder()
            .addProgram(collectorSystem)
            .addProgram(fireSystem);
    @Override
    public ProgramState execute(){

        checkButtons();

        return programState;
    }
    @Override
    public void buttonAReleased() {

    }

    @Override
    public void buttonAUnReleased() {

    }

    @Override
    public void buttonBReleased() {

    }

    @Override
    public void buttonBUnReleased() {

    }

    @Override
    public void buttonXReleased() {

    }

    @Override
    public void buttonXUnReleased() {
        trackingSystem.execute();
        programState = program.execute();
    }

    @Override
    public void buttonYReleased() {

    }

    @Override
    public void buttonYUnReleased() {

    }

    @Override
    public void showData(){
        telemetry.addLine("===AUTO PLAYER===");

        telemetry.addLine();
    }
    public class CollectorSystem extends ExecutableModule {
        private DigitalCellsClass digitalCellsClass;
        private Collector collector;
        public CollectorSystem(OpMode op, HoodedShoter hoodedShoter) {
            super(op, "CollectorSystem");
            collector = hoodedShoter.collector;
            digitalCellsClass = hoodedShoter.digitalCellsClass;
        }
        @Override
        public ProgramState execute() {
            if (digitalCellsClass.getArtifactCount() == 0 && collector.getMotor().setSignal(1, 0.15)){
                collector.setPower(0);
                return ProgramState.Finished;
            }collector.setPower(-1); return ProgramState.Executing;
        }
        @Override
        public void showData() {

        }
    }
    public class FireSystem extends ExecutableModule {
        public FlyWheelClass flyWheelClass;
        public AngleController angleController;
        public DigitalCellsClass digitalCellsClass;
        public SpeedController speedController;
        public FireSystem(OpMode op, HoodedShoter hoodedShoter) {
            super(op, "FireSystem");
            flyWheelClass = hoodedShoter.flyWheelClass;
            angleController = hoodedShoter.angleController;

            speedController = new SpeedController();
            digitalCellsClass = hoodedShoter.digitalCellsClass;
        }
        private ServoMotorWrapper triggeredServo;
        @Override
        public ProgramState execute() {
            digitalCellsClass.update();

            if (digitalCellsClass.getArtifactCount() == 0){
                digitalCellsClass.prepareServo();
                flyWheelClass.setPower(0);
                return ProgramState.Finished;
            }else {
                double[] point = generalInformation.generalObjects.getPointVyr();
                double range = new Vector2(point[0] - odometry.odometryBuffer.read().getRobotPosition().getX(), point[1] - odometry.odometryBuffer.read().getRobotPosition().getY()).length();
                double theta;

                if (range >= 290) theta = 50;
                else if (range >= 150) theta = 60;
                else if (range >= 70) theta = 70;
                else theta = 80;

                double alpha = Math.toRadians(theta);

        //        targetSpeed =  Math.sqrt(Math.abs(981 * range / ((Math.tan(alpha) + Math.tan(targetAngle)) * Math.pow(Math.cos(targetAngle), 2)))) / 100;

        //        targetSpeed = Math.sqrt((981 * Math.pow(range, 2)) / (2 * Math.pow(Math.cos(alpha), 2) * (range * Math.tan(alpha) - (79))))/ 100;

                double targetSpeed = (range / Math.cos(alpha)) * Math.sqrt(Math.abs(981 / (2 * (range * Math.tan(alpha) - 80)))) / 100;

                if (981 / (2 * (range * Math.tan(alpha) - 80)) < 0) targetSpeed = 0;

                targetSpeed = Math.round(targetSpeed * Math.pow(10, 1)) / Math.pow(10, 1);

                double targetRadSpeed = (targetSpeed / MAX_EXPERIMENTAL_SPEED_IN_METERS * MAX_RAD_SPEED) * 19.2;

                double vol = speedController.calculateVol(targetRadSpeed, flyWheelClass.getCurVelocity());
                flyWheelClass.setPower(vol);

                if(angleController.setAngle(theta) && speedController.checkReadnees(flyWheelClass.getCurVelocity(), targetSpeed) && trackingSystem.programState == ProgramState.Finished) {
                    if(!triggeredServo.isBusy()){
                        digitalCellsClass.prepareServo();//Возвращаем серво в начальное положение
                        int index = 3 - digitalCellsClass.getArtifactCount();
                        int neededColor = odometry.cameraClass.motif[index];
                        triggeredServo = digitalCellsClass.fire(neededColor);//выстреливаем
                    }
                }
                return ProgramState.Executing;
            }
        }

        @Override
        public void showData() {

        }
        public class SpeedController{
            public PIDF pidfFlyWheel;
            public SpeedController(){
                pidfFlyWheel = new PIDF(1, 1, 1,1,-1, 1);
            }
            public double calculateVol(double targetSpeed, double curSpeed){

                double pidPower = pidfFlyWheel.calculate(targetSpeed, curSpeed);

                return pidPower;
            }
            public boolean checkReadnees(double curSped, double targetSpeed){
                double errorPart = Math.abs(curSped / targetSpeed - 1);

                if (errorPart > 0.01)
                {
                    return false;
                }
                else {
                    return true;
                }
            }
        }
    }
}

