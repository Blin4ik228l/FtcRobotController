package org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Robot.RobotParts.HoodedShoter.Systems;

import com.qualcomm.robotcore.eventloop.opmode.OpMode;

import org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Robot.RobotParts.HoodedShoter.Modules.Collector;
import org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Robot.RobotParts.HoodedShoter.Modules.DigitalCellsClass;
import org.firstinspires.ftc.teamcode.ModulesAndContainers.Examples.Robot.RobotParts.DriveTrain.ProgramState;
import org.firstinspires.ftc.teamcode.ModulesAndContainers.Modules.Extenders.ExecutableModule;

public class CollectorSystem extends ExecutableModule {
    private DigitalCellsClass digitalCellsClass;
    private Collector collector;
    public CollectorSystem(OpMode op) {
        super(op, "CollectorLogic");
        collector = new Collector(op);
        digitalCellsClass = new DigitalCellsClass(op);
    }
    @Override
    public ProgramState execute() {
        if (digitalCellsClass.getArtifactCount() == 0 && collector.getMotor().setSignal(1, 0.15)){
            collector.setPower(0);
            return ProgramState.Finished;
        }return ProgramState.Executing;
    }
    @Override
    public void showData() {

    }
}
